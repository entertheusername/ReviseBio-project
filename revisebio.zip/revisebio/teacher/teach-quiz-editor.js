// <!-- Chan Zyanne TP075156 -->
document.addEventListener('DOMContentLoaded', () => {
    addQuestionBlock();
});
