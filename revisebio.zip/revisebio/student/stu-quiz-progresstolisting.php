<!-- Woon Wei Jie TP076183 -->
<?php
    echo '<script>alert("Submitted!"); window.location.href = "../student/stu-quiz-listing.php"; </script>';
?>